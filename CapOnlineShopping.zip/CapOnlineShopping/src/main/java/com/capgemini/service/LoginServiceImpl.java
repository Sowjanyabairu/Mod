package com.capgemini.service;

import com.capgemini.dao.ILoginDao;
import com.capgemini.dao.LoginDao;
import com.capgemini.model.LoginBean;

public class LoginServiceImpl implements ILoginService{

	ILoginDao loginDao = new LoginDao();
	@Override
	public boolean checkUser(LoginBean loginBean) {
		return loginDao.checkUser(loginBean);
	}
}


